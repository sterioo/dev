/*-------------------------------- Arctic Core ------------------------------
 * Copyright (C) 2013, ArcCore AB, Sweden, www.arccore.com.
 * Contact: <contact@arccore.com>
 * 
 * You may ONLY use this file:
 * 1)if you have a valid commercial ArcCore license and then in accordance with  
 * the terms contained in the written license agreement between you and ArcCore, 
 * or alternatively
 * 2)if you follow the terms found in GNU General Public License version 2 as 
 * published by the Free Software Foundation and appearing in the file 
 * LICENSE.GPL included in the packaging of this file or here 
 * <http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt>
 *-------------------------------- Arctic Core -----------------------------*/
/***********************************************************************************************************************
 *  INCLUDES
 **********************************************************************************************************************/
#include "Dem_Extension.h"
#include "Dem.h"
#include "Std_Types.h"
#include "Dem_Internal.h"
#include "NvM.h"
#define MEMORY_DEFINE_COUNT
#include "NvM_BLK_Cfg.h"
#undef MEMORY_DEFINE_COUNT

/***********************************************************************************************************************
 *  LOCAL DATA
 **********************************************************************************************************************/
static uint8_t agedCnt[DEM_NOF_DTCS] = {0};
static uint8_t agedCntModified = 0;

void Dem_Extension_MainFunction(void)
{
	Std_ReturnType ret = E_NOT_OK;
	NvM_RequestResultType  RequestResult;
	if (1 == agedCntModified)
	{
		ret = NvM_GetErrorStatus(NVM_BLK_DemPriExtendedDataAgedBlock, &RequestResult);
		if ( (ret == E_OK) && (RequestResult != NVM_REQ_PENDING))
		{
			agedCntModified = 0;
			NvM_WriteBlock(NVM_BLK_DemPriExtendedDataAgedBlock, agedCnt);
		}
	}
}

void Dem_Extension_ClearEvent(const Dem_EventParameterType *eventParam)
{
    (void)eventParam;
	agedCnt[eventParam->EventID-1] = 0;
	agedCntModified                = 1;
}

void Dem_Extension_UpdateEventstatus(EventStatusRecType *eventStatusRecPtr, uint8 eventStatusExtendedBeforeUpdate, Dem_EventStatusType eventStatus)
{
    (void)eventStatusRecPtr;
    (void)eventStatusExtendedBeforeUpdate;
    (void)eventStatus;
}



void Dem_Extension_OperationCycleStart(Dem_OperationCycleIdType operationCycleId, EventStatusRecType *eventStatusRecPtr)
{
    (void)operationCycleId;
    (void)eventStatusRecPtr;
}

void Dem_Extension_OperationCycleEnd(Dem_OperationCycleIdType operationCycleId, EventStatusRecType *eventStatusRecPtr)
{
    (void)operationCycleId;
    (void)eventStatusRecPtr;
}

void Dem_Extension_PreInit(const Dem_ConfigType *ConfigPtr)
{
	Std_ReturnType  ret  = E_NOT_OK;
	uint8_t         iter = 0;
    (void)ConfigPtr;
    ret = NvM_ReadBlock(NVM_BLK_DemPriExtendedDataAgedBlock, agedCnt);
    if (ret != E_OK)
    {
    	for (iter = 0; iter < sizeof(agedCnt)/sizeof(agedCnt[0]); iter++)
    	{
    		agedCnt[iter] = 0;
    	}
    	agedCntModified = 1;
    }
}

void Dem_Extension_Init_PostEventMerge(Dem_DTCOriginType origin)
{
	(void)origin;
}

void Dem_Extension_Init_Complete(void)
{

}

void Dem_Extension_Shutdown(void)
{

}

void Dem_Extension_GetExtendedDataInternalElement(Dem_EventIdType eventId, Dem_InternalDataElementType internalElement, uint8 *dataBuf, uint16 size)
{
    (void)internalElement;
    (void)size;
    EventStatusRecType *eventStatusRec;
    lookupEventStatusRec(eventId, &eventStatusRec);
    dataBuf[0] = (uint8)MIN(eventStatusRec->occurrence, 0xFF);
	dataBuf[1] = (eventStatusRec->eventStatusExtended & DEM_PENDING_DTC) != 0 ?1 : 0;
    dataBuf[2] = agedCnt[eventId-1];
    dataBuf[3] = eventStatusRec->agingCounter;
}

void Dem_Extension_PostPreDebounceCounterBased(Dem_EventStatusType reportedStatus, EventStatusRecType* statusRecord)
{
    (void)reportedStatus;
    (void)statusRecord;
}

void Dem_Extension_HealedEvent(Dem_EventIdType eventId)
{
    (void)eventId;
    if (agedCnt[eventId-1] < 255)
    {
        agedCnt[eventId-1]++;
        agedCntModified = 1;
    }
}

#if defined(DEM_DISPLACEMENT_PROCESSING_DEM_EXTENSION)
void Dem_Extension_GetExtDataEventForDisplacement(const Dem_EventParameterType *eventParam, const ExtDataRecType *extDataBuffer, uint32 bufferSize, Dem_EventIdType *eventToRemove)
{
    (void)eventParam;
    (void)extDataBuffer;
    (void)bufferSize;
    (void)eventParam;
}

void Dem_Extension_GetEventForDisplacement(const Dem_EventParameterType *eventParam, const EventRecType *eventRecordBuffer, uint32 bufferSize, Dem_EventIdType *eventToRemove)
{
    (void)eventParam;
    (void)eventRecordBuffer;
    (void)bufferSize;
    (void)eventParam;
}

void Dem_Extension_GetFFEventForDisplacement(const Dem_EventParameterType *eventParam, const FreezeFrameRecType *ffBuffer, uint32 bufferSize, Dem_EventIdType *eventToRemove)
{
    (void)eventParam;
    (void)ffBuffer;
    (void)bufferSize;
    (void)eventParam;
}
#endif

void Dem_Extension_EventDataDisplaced(Dem_EventIdType eventId)
{
    (void)eventId;
}

void Dem_Extension_EventExtendedDataDisplaced(Dem_EventIdType eventId)
{
    (void)eventId;
}

void Dem_Extension_EventFreezeFrameDataDisplaced(Dem_EventIdType eventId)
{
    (void)eventId;
}

void Dem_Extension_PreMergeExtendedData(Dem_EventIdType eventId, boolean *UpdateAllData)
{
    (void)eventId;
    (void)UpdateAllData;
}
void Dem_Extension_PreTransferPreInitFreezeFrames(Dem_EventIdType eventId, boolean *removeOldRecords, Dem_DTCOriginType origin)
{
    (void)eventId;
    (void)removeOldRecords;
    (void)origin;
}

