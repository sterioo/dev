
// PC-Lint Exception to MISRA rule 19.12: stdio ok in debug.h.
//lint -e(829)


#ifndef DEBUG_H_
#define DEBUG_H_

/**
 *
 * NOTE!!!!
 * Do not use this in a header file. Should be used in the *.c file like this.
 *
 * #define USE_DEBUG_PRINTF
 * #include "debug.h"
 *
 * Macro's for debugging and tracing
 *
 * Define USE_LDEBUG_PRINTF and DBG_LEVEL either globally( e.g. a makefile )
 * or in a specific file.  The DBG_LEVEL macro controls the amount
 * of detail you want in the debug printout.
 * There are 3 levels:
 * DEBUG_LOW    - Used mainly by drivers to get very detailed
 * DEBUG_MEDIUM - Medium detail
 * DEBUG_HIGH   - General init
 *
 * Example:
 * #define DEBUG_LVL	DEBUG_HIGH
 * DEBUG(DEBUG_HIGH,"Starting GPT");
 *
 *
 */

#include <stdio.h>
#if defined(USE_SCI)
#if defined(CFG_RH850F1L)
//#include "serial_sci.h"
#include "Sci.h"
#endif
#endif

#define DEBUG_LOWEST    1u
#define DEBUG_LOW       2u
#define DEBUG_MEDIUM    3u
#define DEBUG_HIGH      4u
#define DEBUG_HIGHEST	5u
#define DEBUG_KERNEL	6u
#define DEBUG_NONE      7u

#ifndef DEBUG_LVL
#define DEBUG_LVL       DEBUG_NONE
#endif


#define CH_ISR          0u
#define CH_PROC         1u

#if defined(DBG)
#define dbg(...) //printf(__VA_ARGS__ )
#else
#define dbg(...)
#endif

#if defined(_DEBUG_)
#define _debug_(...) //printf (__VA_ARGS__);
#else
#define _debug_(...)
#endif

#if defined(USE_DEBUG_PRINTF)
#define DEBUG(_level, ...) \
		do{ \
			if(_level >= DEBUG_LVL){ \
				printf(__VA_ARGS__); \
			} \
		}while(0);
#else
#define DEBUG(_level,...)
#endif

#if defined(USE_LDEBUG_PRINTF)
#define debug(...)                  //printf(__VA_ARGS__)
#define LDEBUG_PRINTF(format,...) 	//printf(format,## __VA_ARGS__ )
#define LDEBUG_FPUTS(_str) 			//fputs((_str),stdout)
#else
#define LDEBUG_PRINTF(format,...)
#define LDEBUG_FPUTS(_str)
#endif

#define UART_DEBUG_PRINTF(_level, ...) \
		do{ \
			if(_level >= DEBUG_LVL){ \
				printf(__VA_ARGS__); \
			} \
		}while(0);


char *_ftoa(double number, int ndigit, char *buf);
void* memmalloc(size_t sz);
void memfree(void* ptr);

#endif /*DEBUG_H_*/
