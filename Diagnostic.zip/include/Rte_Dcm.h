/**
 * Application Header File
 *
 * @req SWS_Rte_01003
 */

/** === HEADER ====================================================================================
 */

/** --- C++ guard ---------------------------------------------------------------------------------
 * @req SWS_Rte_03709
 */
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/** --- Normal include guard ----------------------------------------------------------------------
 */
#ifndef RTE_DCM_H_
#define RTE_DCM_H_

/** --- Duplicate application include guard -------------------------------------------------------
 * @req SWS_Rte_01006
 */
#ifdef RTE_APPLICATION_HEADER_FILE
#error Multiple application header files included.
#endif
#define RTE_APPLICATION_HEADER_FILE

/** --- Single runnable API -----------------------------------------------------------------------
 * @req SWS_Rte_02751
 */
#if defined(RTE_RUNNABLEAPI_Dcm_GetSecurityLevel) || \
defined(RTE_RUNNABLEAPI_Dcm_GetSesCtrlType) || \
defined(RTE_RUNNABLEAPI_Dcm_GetActiveProtocol) || \
defined(RTE_RUNNABLEAPI_Dcm_ResetToDefaultSession) || \
defined(RTE_RUNNABLEAPI_Dcm_MainFunction)
#define RTE_RUNNABLEAPI
#endif

/** --- Includes ----------------------------------------------------------------------------------
 * @req SWS_Rte_02751
 * @req SWS_Rte_07131
 */
#include <Rte_Dcm_Type.h>
#include "DcmCbk.h"
/** --- Application Errors ------------------------------------------------------------------------
 * @req SWS_Rte_02575
 * @req SWS_Rte_02576
 * @req SWS_Rte_07143
 */
#define RTE_E_CallbackDCMRequestServices_E_NOT_OK 1U
#define RTE_E_CallbackDCMRequestServices_E_OK 0U
#define RTE_E_CallbackDCMRequestServices_E_PROTOCOL_NOT_ALLOWED 5U
#define RTE_E_DCMServices_E_NOT_OK 1U
#define RTE_E_DCMServices_E_OK 0U
#define RTE_E_DcmIf_DEM_CLEAR_FAILED 4U
#define RTE_E_DcmIf_DEM_CLEAR_OK 0U
#define RTE_E_DcmIf_DEM_CLEAR_PENDING 5U
#define RTE_E_DcmIf_DEM_CLEAR_WRONG_DTC 1U
#define RTE_E_DcmIf_DEM_CLEAR_WRONG_DTCKIND 3U
#define RTE_E_DcmIf_DEM_CLEAR_WRONG_DTCORIGIN 2U
#define RTE_E_SecurityAccess_SecurityLevel_0_E_COMPARE_KEY_FAILED 11U
#define RTE_E_SecurityAccess_SecurityLevel_0_E_NOT_OK 1U
#define RTE_E_SecurityAccess_SecurityLevel_0_E_OK 0U
#define RTE_E_SecurityAccess_SecurityLevel_0_E_PENDING 10U
/** === FOOTER ====================================================================================
 */
#endif /* RTE_DCM_H_ */

