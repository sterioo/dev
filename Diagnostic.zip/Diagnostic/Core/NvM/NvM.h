/*
 * NvM.h
 *
 *  Created on: 20201115
 *      Author: zhuwl
 */


#define NVM_SW_MAJOR_VERSION	1u
#define NVM_SW_MINOR_VERSION	2u
#include "Std_Types.h"
#include "Rte_Type.h"
#include "Platform_Types.h"
#include "NvM_Cfg.h"

#ifndef NVM_REQ_OK
#define NVM_REQ_OK 0U
#endif /* NVM_REQ_OK */

#ifndef NVM_REQ_NOT_OK
#define NVM_REQ_NOT_OK 1U
#endif /* NVM_REQ_NOT_OK */

#ifndef NVM_REQ_PENDING
#define NVM_REQ_PENDING 2U
#endif /* NVM_REQ_PENDING */



void NvM_Init(void);
Std_ReturnType NvM_GetErrorStatus(/*IN*/NvM_BlockIdType portDefArg1, /*OUT*/NvM_RequestResultType * RequestResultPtr);
void NvM_SetBlockLockStatus( NvM_BlockIdType blockId, boolean blockLocked );
Std_ReturnType NvM_WriteBlock(/*IN*/NvM_BlockIdType blockno, /*IN*/ConstVoidPtr buffer);
Std_ReturnType NvM_ReadBlock(/*IN*/NvM_BlockIdType portDefArg1, /*IN*/VoidPtr DstPtr);
void NvM_ReadAll(void);
void NvM_MainFunction(void);
#if (NVM_SET_RAM_BLOCK_STATUS_API == STD_ON)
Std_ReturnType NvM_SetRamBlockStatus( NvM_BlockIdType blockId, boolean blockChanged );	/** @req NVM453 */
#endif
